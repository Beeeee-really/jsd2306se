package homework.day02;

public class Four {
    public static void main(String[] args) {
        /*
         * 原因:
         * 包含空格
         */
//        String num = "123 ";
//        int d = Integer.parseInt(num);
//        System.out.println(d);

        /*
         * 原因:
         * double类型
         */
//        String num = "123.456";
//        int d = Integer.parseInt(num);
//        System.out.println(num);

        /*
         * 原因:
         * 可转为int
         */
//		String num = "123";
//		int d = Integer.parseInt(num);
//		System.out.println(d);
    }
}
